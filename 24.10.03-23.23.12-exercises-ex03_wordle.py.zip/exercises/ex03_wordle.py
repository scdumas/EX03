"Creating Wordle Game Loop"

__author__: str = "730482702"


def input_guess(secret_characters: int) -> str:
    """Confirming if guessed word has same number of characters as secret word"""
    guessed_word: str = input(f"Enter a {secret_characters} character word")
    # make sure to include f so the secret_characters is able to change
    while secret_characters != len(guessed_word):
        guessed_word = str(input(f"That wasn't {secret_characters} chars! Try again:"))
    return guessed_word


def contains_char(secret_word: str, character: str) -> bool:
    """identify if the letter guessed is in the secret word and identify where"""
    assert len(character) == 1
    # you can only insert one character
    idx: int = 0
    character_match: int = 0
    while idx < len(secret_word):
        if secret_word[idx] == character:
            character_match += 1
        else:
            character_match = character_match
        idx += 1
    if character_match >= 1:
        return True
    else:
        return False


def emojified(secret_word: str, guessed_word: str) -> str:
    "Compare two strings of equal length"
    assert len(secret_word) == len(
        guessed_word
    )  # words must be same number of characters
    GREEN_BOX: str = "\U0001F7E9"
    # make sure you have right amount of 0s otherwise it won't work
    YELLOW_BOX: str = "\U0001F7E8"
    WHITE_BOX: str = "\U00002B1C"
    # white is the only one with 4 0s
    idx: int = 0
    emoji_sequence: str = ""
    # must create blank string to add to over time and get list of emojis over time
    while idx < len(guessed_word):
        if guessed_word[idx] == secret_word[idx]:
            emoji_sequence = emoji_sequence + GREEN_BOX
            idx = idx + 1
            # must add given emoji depending on response to blank emoji str
        else:
            if (
                contains_char(secret_word=secret_word, character=guessed_word[idx])
            ) is True:
                emoji_sequence = emoji_sequence + YELLOW_BOX
            else:
                emoji_sequence += WHITE_BOX
    idx += 1
    return emoji_sequence


def main(secret: str) -> None:
    """Connect all the functions together"""
    turns: int = 1
    tries: int = 6
    win: int = 0  # needed to create this variable of win to determine if you continue
    # need to keep track of turns, must start with first turn = 1
    while turns <= tries and win == 0:
        print(f"=== Turn {turns}/{tries} ===")
        # must change the number of turns and add one with each try
        newguess: str = input_guess(len(secret))
        print(emojified(secret_word=secret, guessed_word=newguess))
        if newguess == secret:
            win = 1
            # you must call on the functions you created previously to linkt them
        else:
            turns = turns + 1

    if win == 1:
        print(f"You won in {turns}/{tries} turns!")
        # win statement
    else:
        print(f"X/{tries} - Sorry, try again tomorrow!")
        return  # needed some sort of return


if __name__ == "__main__":
    main(secret="codes")
    # this needs to go at the bottom
